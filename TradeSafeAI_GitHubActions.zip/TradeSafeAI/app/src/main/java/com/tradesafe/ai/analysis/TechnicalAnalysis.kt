package com.tradesafe.ai.analysis

import com.tradesafe.ai.data.*
import kotlin.math.abs

object TechnicalAnalysis {
    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val k = 2.0 / (period + 1)
        var e = values.take(period.coerceAtMost(values.size)).average()
        values.drop(period.coerceAtMost(values.size)).forEach { e = it * k + e * (1-k) }
        return e
    }
    private fun rsi(values: List<Double>, period: Int = 14): Double {
        if (values.size <= period) return 50.0
        var gain = 0.0; var loss = 0.0
        for (i in values.size-period until values.size) {
            val d = values[i] - values[i-1]
            if (d >= 0) gain += d else loss -= d
        }
        if (loss == 0.0) return 100.0
        val rs = gain / loss
        return 100.0 - (100.0 / (1 + rs))
    }
    fun analyze(m: Market): SignalResult {
        val c = m.candles
        val closes = c.map { it.close }
        val last = closes.last()
        val fast = ema(closes, 9); val slow = ema(closes, 21); val r = rsi(closes)
        val recent = c.takeLast(20)
        val support = recent.minOf { it.low }; val resistance = recent.maxOf { it.high }
        val trendBull = fast > slow; val momentumBull = r in 52.0..72.0
        val trendBear = fast < slow; val momentumBear = r in 28.0..48.0
        val buyScore = (if (trendBull) 45 else 0) + (if (momentumBull) 30 else 0) + (if (last > support * 1.01) 15 else 0) + (if (m.changePct > 0) 10 else 0)
        val sellScore = (if (trendBear) 45 else 0) + (if (momentumBear) 30 else 0) + (if (last < resistance * .99) 15 else 0) + (if (m.changePct < 0) 10 else 0)
        val signal = when { buyScore >= 65 -> Signal.BUY; sellScore >= 65 -> Signal.SELL; else -> Signal.WAIT }
        val confidence = maxOf(buyScore, sellScore).coerceAtMost(96)
        val risk = (last * .015).coerceAtLeast(last * .005)
        return when(signal) {
            Signal.BUY -> SignalResult(signal, confidence, last*.998, last*1.002, last-risk, last+risk*2, last+risk*3.5, 1.0, listOf("EMA 9 выше EMA 21", "RSI ${r.toInt()} — импульс положительный", "Цена выше ближайшей поддержки"))
            Signal.SELL -> SignalResult(signal, confidence, last*.998, last*1.002, last+risk, last-risk*2, last-risk*3.5, 1.0, listOf("EMA 9 ниже EMA 21", "RSI ${r.toInt()} — импульс слабый", "Цена под локальным сопротивлением"))
            Signal.WAIT -> SignalResult(signal, confidence, last*.995, last*1.005, last-risk, last+risk*2, last+risk*3, .5, listOf("Тренд и импульс не дают согласованного входа", "Лучше дождаться подтверждения"))
        }
    }
}
