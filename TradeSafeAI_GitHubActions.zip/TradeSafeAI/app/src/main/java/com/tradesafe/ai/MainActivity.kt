package com.tradesafe.ai

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradesafe.ai.analysis.TechnicalAnalysis
import com.tradesafe.ai.data.*
import kotlinx.coroutines.delay

private val Bg=Color(0xFF090B10); private val Card=Color(0xFF11151D); private val Muted=Color(0xFF8992A3); private val Green=Color(0xFF35D07F); private val Red=Color(0xFFFF5C6C); private val Accent=Color(0xFF7C6CFF)

class MainActivity: ComponentActivity() {
    private val captureCode=701
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App { requestScreenCapture() } } }
    private fun requestScreenCapture(){ val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(),captureCode) }
}

@Composable fun App(onCapture:()->Unit){
    var market by remember { mutableStateOf(DemoMarket.market()) }
    var selected by remember { mutableStateOf("SBER") }
    var tab by remember { mutableIntStateOf(0) }
    var analyzing by remember { mutableStateOf(true) }
    LaunchedEffect(analyzing){ while(analyzing){ delay(2500); market=DemoMarket.market(selected) } }
    val result=remember(market){ TechnicalAnalysis.analyze(market) }
    MaterialTheme(colorScheme=darkColorScheme(background=Bg, surface=Card, primary=Accent)){
        Scaffold(containerColor=Bg, bottomBar={NavigationBar(containerColor=Color(0xFF0C0F15)){ listOf("Главная","Рынок","Сигналы","Портфель").forEachIndexed{ i,t-> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","◉","⚡","▣")[i])},label={Text(t, fontSize=10.sp)}) } }}) { pad ->
            LazyColumn(modifier=Modifier.padding(pad).padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(vertical=16.dp)){
                item{ Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){ Column{ Text("TRADE SAFE AI", fontWeight=FontWeight.Bold, fontSize=20.sp); Text("AI-аналитика рынка", color=Muted, fontSize=12.sp) }; Row(verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(8.dp).background(Green, RoundedCornerShape(50))); Spacer(Modifier.width(6.dp)); Text(if(analyzing)"LIVE" else "PAUSE", color=Green, fontSize=12.sp) } } }
                item{ Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("SBER","GAZP","LKOH").forEach{ s-> FilterChip(selected=selected==s,onClick={selected=s; market=DemoMarket.market(s)},label={Text(s)}) } } }
                item{ Card(shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Card)){ Column(Modifier.padding(16.dp)){ Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ Column{Text(selected, fontWeight=FontWeight.Bold,fontSize=22.sp);Text(if(selected=="SBER")"Сбербанк" else "Демо-инструмент",color=Muted,fontSize=12.sp)}; Column(horizontalAlignment=Alignment.End){Text("₽ ${"%.2f".format(market.price)}",fontWeight=FontWeight.Bold,fontSize=22.sp);Text("${if(market.changePct>=0)"+" else ""}${"%.2f".format(market.changePct)}%",color=if(market.changePct>=0)Green else Red)}}; Spacer(Modifier.height(12.dp)); PriceChart(market.candles); Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("1Д",color=Accent); Text("5Д",color=Muted); Text("1М",color=Muted); Text("6М",color=Muted); Text("1Г",color=Muted)} } } }
                item{ val sc=when(result.signal){Signal.BUY->Green;Signal.SELL->Red;Signal.WAIT->Color(0xFFFFC857)}; Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Card)){ Column(Modifier.padding(16.dp)){ Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Column{Text("СИГНАЛ",color=Muted,fontSize=11.sp);Text(result.signal.name,fontWeight=FontWeight.Black,fontSize=30.sp,color=sc)}; Column(horizontalAlignment=Alignment.End){Text("Уверенность",color=Muted,fontSize=11.sp);Text("${result.confidence}%",fontSize=22.sp,fontWeight=FontWeight.Bold)} }; Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ Metric("Вход","${"%.2f".format(result.entryLow)}–${"%.2f".format(result.entryHigh)}");Metric("Стоп","${"%.2f".format(result.stop)}");Metric("TP1","${"%.2f".format(result.tp1)}");Metric("TP2","${"%.2f".format(result.tp2)}")}; Spacer(Modifier.height(14.dp)); Text("Почему",fontWeight=FontWeight.Bold); result.reasons.forEach{Text("• $it",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))}; Spacer(Modifier.height(14.dp)); Button(onClick={onCapture()},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("АНАЛИЗИРОВАТЬ ЭКРАН")}; Spacer(Modifier.height(6.dp)); Text("Не является финансовой рекомендацией. Проверяйте сигнал перед сделкой.",color=Muted,fontSize=10.sp) } } }
                item{ Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ InfoCard("RSI","${(result.confidence+20).coerceAtMost(78)}", "Импульс"); InfoCard("EMA","9 / 21","Тренд"); InfoCard("Риск","${result.riskPct}%","На сделку") } }
                item{ Text("Последние сигналы",fontSize=18.sp,fontWeight=FontWeight.Bold); listOf("SBER • BUY • 78%","GAZP • WAIT • 54%","LKOH • SELL • 71%").forEach{ Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it, color=Color.LightGray);Text("›",color=Muted)} } }
            }
        }
    }
}
@Composable fun Metric(a:String,b:String){Column{Text(a,color=Muted,fontSize=10.sp);Text(b,fontWeight=FontWeight.SemiBold,fontSize=13.sp)}}
@Composable fun InfoCard(a:String,b:String,c:String){Card(modifier=Modifier.weight(1f),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp)){Text(a,color=Muted,fontSize=10.sp);Text(b,fontWeight=FontWeight.Bold);Text(c,color=Muted,fontSize=10.sp)}}}
@Composable fun PriceChart(candles:List<Candle>){ Canvas(Modifier.fillMaxWidth().height(190.dp)){ val min=candles.minOf{it.low};val max=candles.maxOf{it.high};val path=Path(); candles.forEachIndexed{i,c-> val x=i*(size.width/(candles.size-1));val y=size.height-((c.close-min)/(max-min)*size.height);if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}; drawPath(path,Color(0xFF8D7CFF),style=Stroke(3f)); for(i in 0..4){val y=i*size.height/4;drawLine(Color(0xFF1D2330),Offset(0f,y),Offset(size.width,y),1f)} } }
