package com.tradesafe.ai.data

enum class Signal { BUY, SELL, WAIT }
data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class Market(val symbol: String, val name: String, val price: Double, val changePct: Double, val candles: List<Candle>)
data class SignalResult(val signal: Signal, val confidence: Int, val entryLow: Double, val entryHigh: Double, val stop: Double, val tp1: Double, val tp2: Double, val riskPct: Double, val reasons: List<String>)
