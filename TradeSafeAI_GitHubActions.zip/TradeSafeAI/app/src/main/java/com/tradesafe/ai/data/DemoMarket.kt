package com.tradesafe.ai.data

import kotlin.random.Random

object DemoMarket {
    fun market(symbol: String = "SBER"): Market {
        var p = 309.45
        val list = mutableListOf<Candle>()
        repeat(80) {
            val o = p; p += Random.nextDouble(-2.2, 2.5); val cl = p
            val hi = maxOf(o, cl) + Random.nextDouble(.2, 1.8); val lo = minOf(o, cl) - Random.nextDouble(.2, 1.8)
            list += Candle(o, hi, lo, cl, Random.nextDouble(1000.0, 9000.0))
        }
        return Market(symbol, "Сбербанк", p, (p-309.45)/309.45*100, list)
    }
}
