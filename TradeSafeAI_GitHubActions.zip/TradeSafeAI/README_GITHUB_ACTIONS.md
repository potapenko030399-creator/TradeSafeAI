# Trade Safe AI — GitHub Actions build

## Как получить APK без Android Studio

1. Создай новый репозиторий на GitHub.
2. Загрузи в него содержимое этой папки `TradeSafeAI`.
3. Открой вкладку **Actions**.
4. Выбери workflow **Build Trade Safe AI APK**.
5. Нажми **Run workflow**.
6. После завершения открой успешный запуск workflow и скачай artifact **TradeSafeAI-debug-apk**.
7. Внутри будет `app-debug.apk` — его можно установить на Android.

Workflow также автоматически запускается при push в `main` или `master`.

## Важно

Это debug APK для тестирования. Реальные биржевые котировки, API брокера и автоматическое выставление заявок в текущем прототипе не подключены. Сигналы аналитического модуля не являются гарантией прибыли.
